﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration.UserSecrets;
using raceday.Models;
using System.Security.Claims;
using System.Text;


namespace raceday.Controllers
    [ApiController]
[Route("api/auth")]
public class AuthController : ControllerBase    
{
    private readonly UserManager<User_controller> user;
    private readonly IConfiguration configuration;
    
        public AuthController(
            UserManager<User_controller> users,
            IConfiguration configuration
            )
    {
        _user = users;
        this.configuration = configuration;
    }

    public record RegisterRequest(
        string FullName,
        string Email,
        string Password);

    [HttpPost("register")]
    public async Task<IActionResult> register(RegisterRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.FullName))||
                string.IsNullOrWhiteSpace(request.Email) ||
                string.IsNullOrWhiteSpace(request.Password)
                {
            return BadRequest("All fields are required.");
        }
        var user = new user
        {
            UserName = request.Email,
            Email = request.Email,
            FullName = request.FullName
        };

        var result = await _users.CreateAsync(user, request.Password);
        if (!result.Succeeded)
        {
            return BadRequest(result.Errors.Select(equals => equals.Description));
        }
        await _users.AddToRoleAsync(user, "Participant");
        return Ok(new { message = "Participant registered successfully." });
    }
    
