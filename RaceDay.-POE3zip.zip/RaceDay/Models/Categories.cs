﻿namespace raceday.Models
{
    public class Categories
    {
        public int Id { get; set; }

        public int EventId { get; set; }

        public Events? Events { get; set; }

        public string Name { get; set; } = string.Empty;

        public string CategoryType { get; set; } = string.Empty;

        public int? MinimumAge { get; set; }
        public int? MaximumAge { get; set; }

        public double? Distance { get; set; }
    }
}
