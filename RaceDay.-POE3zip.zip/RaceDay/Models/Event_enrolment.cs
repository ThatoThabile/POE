﻿namespace raceday.Models
{
    public class Event_enrolment
    {
        public int Id { get; set; }

        public string ParticipantId { get; set; }=string.Empty;
        public User? Participant { get; set; }

        public int EventId { get; set; }
        public Events? Events { get; set; }

        public int CategoryId { get; set; }
        public Categories? Categories { get; set; }
        public DateTime EnrolmentAt { get; set; }=DateTime.Now;
    }
}
