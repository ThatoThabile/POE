﻿namespace raceday.Models;

public enum EventType
{
    Run,
    Walk,
    Cycle
}
    public class Events
    {
        public int Id { get; set; }

        public string Name { get; set; }=string.Empty;
        public string Description { get; set; } = string.Empty;

        public DateTime Date { get; set; }
        public string Location { get; set; }=string.Empty;

        public double Distance { get; set; }

        public EventType EventType { get; set; }
    public string OrganiserID { get; set; } = string.Empty;
    public User? Organiser { get; set; }
    public ICollection<Categories> Categories { get; set; }
        = new List<Categories>();
    }

