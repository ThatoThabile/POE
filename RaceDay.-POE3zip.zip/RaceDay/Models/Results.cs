﻿namespace raceday.Models
{
    public class Results
    {
        public int Id { get; set; }

        public int EnrolmentId { get; set; }
        public Event_enrolment? Event_enrolment { get; set; }

        //finishing time, stored as elapsed time.
        public TimeSpan FinishTime { get; set; }

        public int FinishingPosition { get; set; }
    }
}
